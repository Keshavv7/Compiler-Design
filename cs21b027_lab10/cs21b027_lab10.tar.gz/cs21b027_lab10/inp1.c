a = b + 20;
switch (a)
{
case b:
    a = 10;
    break;
case 5:
    j = l--;
default:
    a = 0;
}
if (x < y && u == 7)
{
    a++;
}
else
{
    b--;
}
while (v)
{
    a--;
}