while (j < l)
{
    if (u == 9)
    {
        switch (j)
        {
        case g:
            k--;
            break;

        default:
            j--;
            break;
        }
    }
}