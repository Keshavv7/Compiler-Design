switch (j)
{
case g:
    switch (k)
    {
    case 9:
        j--;
        break;
    default:
        j++;
        break;
    }
default:
    j--;
    break;
}