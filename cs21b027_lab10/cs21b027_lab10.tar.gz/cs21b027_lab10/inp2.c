switch (f)
{
case 5:
    if (a < k)
    {
        a++;
    }
    else
    {
        b--;
    }
case b:
    a = 10;
    break;
default:
    a = 0;
    break;
}