a=a+b;
while(--a<b++ || b>c){
while(c==d || false){
}
while(true && asd!=dsa){
} 
}
c =c^d^e;
