while(a<b || 56==a && a+b>c*d){
if(a<b && c<b){
c = a+b;
}else{
if(a==b){

c = a*b;
}}
c=a-b;
}
a = 1+0;
