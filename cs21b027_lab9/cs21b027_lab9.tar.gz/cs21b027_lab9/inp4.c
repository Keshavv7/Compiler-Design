k = 0;
while (k < n || n != 100) {
if (x < 100) {
a++;
}
else {
a--;
}
y = a ;
k++;
}
k = m + n;
