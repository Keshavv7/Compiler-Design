while((a&&b)){
a = true;
}
e=e;
while(!a){
a=a+d;
}
c=c-d;
